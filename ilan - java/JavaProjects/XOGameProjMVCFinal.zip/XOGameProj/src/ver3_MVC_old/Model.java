package ver3_MVC;

/**
 * Model - XO Game Logic
 * 26/1/2021
 * By Ilan Peretz (ilanperets@gmail.com).
 */
public class Model 
{
    // תכונות
    private char[][] logicBoard;   // לוח משחק לוגי
    
    /**
     * 
     * @param boardSize 
     */
    public Model(int boardSize)
    {
        // יצירת לוח לוגי לצורך בדיקות וקבלת החלטות במשחק
        logicBoard = new char[boardSize][boardSize];
    }
    
    // פעולה לאתחול לוגי של משחק חדש
    public void setup()
    {
       
    }
}
