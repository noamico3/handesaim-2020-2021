package ver3_MVC;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * XO Game - המשחק איקס עיגול בגרסה המשתמשת במערך דינמי של מיקומים.
 * 17/11/2020
 * By Ilan Peretz (ilanperets@gmail.com)
 */
public class Main
{
    // קבועים
    static final String WIN_TITLE = "XO Game (ver2)";
    static final int BUTTON_SIZE = 120;  // ממדי הכפתור בלוח המשחק
   
 
    static char player;         // סימן השחקן שתורו לשחק כעת

    
    // הפעולה הראשית
    public static void main(String[] args)
    {
        initGame();     // איתחול המשחק
        createGUI();    //יצירת ממשק משתמש למשחק 
        newGame();      // התחלת משחק חדש
    }

    // איתחול המשחק בדברים שצריך לעשות לפני יצירת הממשק
    private static void initGame()
    {
        // load assets...
    }



    // בעת לחיצה על כפתור תזומן פעולה זו
    public static void doHumanMove(JButton btn)
    {
        System.out.println(">> buttonClicked");

        // סימן השחקן על הכפתור
        btn.setText(player + "");

        // נעילת הכפתור
        btn.setEnabled(false);

        // בדיקת מצב המשחק
        // האם המשחק ניגמר בניצחון או בתיקו או ממשיכים לשחק
        checkGameStatus();
    }

    // הפעולה בודקת את מצב המשחק
    // האם המשחק ניגמר בניצחון או תיקו
    // אם המשחק לא ניגמר אז מבצעים החלפת תור שחקן
    private static void checkGameStatus()
    {
        System.out.print(">> checkGameStatus: ");

        //1. נבדוק האם יש ניצחון לשחקן הנוכחי זה ששיחק כעת
        // =============================================
        ArrayList<Location> winLocs = checkWin(player);
        if (winLocs != null)
        {
            System.out.println(player + " WIN!");
            lblMsg.setText("Game Over - " + player + " Win!");
            setBoardButtonsEnabled(false);    // נעילת כל הכפתורים
            btnAI.setEnabled(false);
            btnNewGame.setEnabled(true);
            lblMsg.setBackground(Color.GREEN);
            colorWinLoc(winLocs);
            return;
        }

        //2. נבדוק האם יש תיקו כלומר נגמר המשחק ואף אחד לא ניצח
        // ====================================================
        if (checkTie() == true)
        {
            System.out.println("Game Over - Tie!");
            lblMsg.setText("Game Over - Tie!");
            btnAI.setEnabled(false);
            btnNewGame.setEnabled(true);
            lblMsg.setBackground(Color.GREEN);
            return;
        }

        //3. אין ניצחון ואין תיקו מחליפים תור וממשיכים לשחק
        // ====================================================
        System.out.println("switch players & continue to play...");

        // החלפת סימן שחקן תור מתחלף
        if (player == 'X')
        {
            player = 'O';
        } else
        {
            player = 'X';
        }
        lblMsg.setText(player + " Turn");
    }

    // פעולה לבדיקת ניצחון עבור שחקן מסוים
    // הפעולה מקבלת סימן של שחקן ובודקת האם יש לו ניצחון
    // אם יש לשחקן ניצחון הפעולה מחזירה מערך דינמי של מיקומים
    // nullאם אין לשחקן ניצחון הפעולה מחזירה 
    public static ArrayList<Location> checkWin(char player)
    {
        // רשימת מיקומי 
        ArrayList<Location> winLocList = new ArrayList();

        // נבדוק האם יש ניצחון לשחקן הנוכחי באחת מהשורות
        for (int row = 0; row < ROWS; row++)
        {
            winLocList.clear();
            for (int col = 0; col < COLS; col++)
            {
                if (btnMat[row][col].getText().charAt(0) != player)
                {
                    break;
                } else
                {
                    winLocList.add(new Location(row, col));
                }
            }
            if (winLocList.size() == ROWS)
            {
                return winLocList;
            }
        }

        // נבדוק האם יש ניצחון לשחקן הנוכחי באחת מהעמודות
        for (int col = 0; col < COLS; col++)
        {
            winLocList.clear();
            for (int row = 0; row < ROWS; row++)
            {
                if (btnMat[row][col].getText().charAt(0) != player)
                {
                    break;
                } else
                {
                    winLocList.add(new Location(row, col));
                }
            }
            if (winLocList.size() == COLS)
            {
                return winLocList;
            }
        }

        // נבדוק האם יש ניצחון לשחקן הנוכחי באלכסון הראשי
        winLocList.clear();
        for (int i = 0; i < ROWS; i++)
        {
            if (btnMat[i][i].getText().charAt(0) != player)
            {
                break;
            } else
            {
                winLocList.add(new Location(i, i));
            }
        }
        if (winLocList.size() == ROWS)
        {
            return winLocList;
        }

        // נבדוק האם יש ניצחון לשחקן הנוכחי באלכסון משני
        winLocList.clear();
        for (int i = 0; i < ROWS; i++)
        {
            if (btnMat[i][ROWS - i - 1].getText().charAt(0) != player)
            {
                break;
            } else
            {
                winLocList.add(new Location(i, ROWS - i - 1));
            }
        }
        if (winLocList.size() == ROWS)
        {
            return winLocList;
        }

        // אם הגענו לכאן לא נמצא ניצחון בלוח
        return null;
    }

    // פעולה שבודקת האם המשחק נגמר בתיקו
    // true אם כן הפעולה מחזירה
    // false אם לא הפעולה מחזירה
    public static boolean checkTie()
    {
        for (int row = 0; row < ROWS; row++)
        {
            for (int col = 0; col < COLS; col++)
            {
                // אם יש כפתור פנוי אז אין תיקו
                if (btnMat[row][col].getText().equals(" "))
                {
                    return false;
                }
            }
        }

        // אם היגענו לכאן זה אומר שיש תיקו
        return true;
    }

    // פעולה לנעילה או פתיחה של כל כפתורי הלוח על פי הפרמטר שמתקבל
    // status=true - נעילה
    // status=false - פתיחה
    private static void setBoardButtonsEnabled(boolean status)
    {
        for (int row = 0; row < ROWS; row++)
        {
            for (int col = 0; col < COLS; col++)
            {
                btnMat[row][col].setEnabled(status);
            }
        }
    }

    // פעולה שמנקה את כפתורי לוח המשחק
    private static void cleanBoard()
    {
        for (int row = 0; row < ROWS; row++)
        {
            for (int col = 0; col < COLS; col++)
            {
                btnMat[row][col].setText(" ");
                btnMat[row][col].setBackground(Color.WHITE);
            }
        }
    }

    // פעולה למשחק חדש
    private static void newGame()
    {
        // 1. ניקוי הלוח
        cleanBoard();

        // 2. לפתוח נעילות כפתורים
        setBoardButtonsEnabled(true);
        btnNewGame.setEnabled(false);
        btnAI.setEnabled(true);

        // 3. שחקן מתחיל והודעה
        player = 'X';
        lblMsg.setText(player + " Turn");
        lblMsg.setBackground(null);
    }

    // פעולה שצובעת את מיקום הניצחון
    private static void colorWinLoc(ArrayList<Location> winLocList)
    {
        for (int i = 0; i < winLocList.size(); i++)
        {
            Location loc = winLocList.get(i);
            btnMat[loc.getRow()][loc.getCol()].setBackground(Color.YELLOW);
        }
    }

    // ביצוע מהלך של שחקן ממוחשב
    private static void doAIMove()
    {
        for (int row = 0; row < ROWS; row++)
        {
            for (int col = 0; col < COLS; col++)
            {
                if (btnMat[row][col].getText().equals(" "))
                {
                    // option 1
                    //btnMat[row][col].setText(player+"");
                    //checkGameStatus();

                    // option 2
                    doHumanMove(btnMat[row][col]);
                    return;
                }
            }
        }
    }
}
