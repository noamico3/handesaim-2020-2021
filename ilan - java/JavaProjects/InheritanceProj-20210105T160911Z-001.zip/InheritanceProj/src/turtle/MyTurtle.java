package turtle;

import java.awt.Color;
import unit4.turtleLib.Turtle;

/**
 * MyTurtle
 * 5/1/2021
 * By Ilan Peretz (ilanperets@gmail.com)
 */
public class MyTurtle extends Turtle
{
    public MyTurtle()
    {
        super();
    }
    
    
    public void drawCircle(double radius, Color color)
    {
        super.setTailColor(color);
        super.tailUp();
        
        int step = 1;
        for (int i= 1; i <= 360; i=i+step)        
        {
            super.moveForward(radius);
            super.tailDown();
            super.moveForward(1);
            super.tailUp();
            super.moveBackward(radius+1);
            super.turnRight(step);
        }
    }
}
