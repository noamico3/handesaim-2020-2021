package turtle;

import java.awt.Color;
import javax.swing.JOptionPane;


/**
 * TurtleDemo - This program do ...
 * 5/1/2021
 * By Ilan Peretz (ilanperets@gmail.com)
 */
public class TurtleDemo
{
    public static void main(String[] args)
    {
        MyTurtle t1 = new MyTurtle();
        t1.tailDown();
        t1.setTailColor(Color.BLUE);
        t1.setDelay(20);
        
        int n = 10;
        for (int k = 1; k  <= n; k ++)        
        {
            for (int i = 1; i <=4; i++)        
            {
                t1.moveForward(100);
                t1.turnRight(90);
            }
            t1.turnRight(360.0/n);
        }
        
        t1.setDelay(1);
        t1.setVisible(false);
        t1.drawCircle(150, Color.RED);
        
        JOptionPane.showMessageDialog(null, "Well done!\nPress OK to close & exit ...");
        System.exit(0);
    }
}
